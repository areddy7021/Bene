Migration Scheduler
=====================================================

Please follow the instructions below to build and execute the application with various profiles.

### Folder Structure

    .
    ├── src                                           # Source files
    ├──── main                                        # contails source code and properties
    ├────── java                                      # .java files
    ├──────── com.uhc                                 # package structure     
    ├────────── controller                            # Controller class to accept request 
    ├────────── model                                 # Model - Database table ORM classes  
    ├────────── repo                                  # JPA Repositories to connect to database tables
    ├────────── schema.model                          # AVRO auto-generaged from schema files
    ├────────── service                               # Service Layer  
    ├────────── utils                                 # Utility Classes for mapping
    ├────── resources                                 # application resources like configuration properties
    ├────────── benefits                              # Benefits - contains ca certs, pem & jks files required to connect to kafka topic
    ├────────── eligibility                           # Eligibility - contains ca certs, pem & jks files required to connect to kafka topic
    ├────────── preferences                           # Preferences - contains ca certs, pem & jks files required to connect to kafka topic
    ├────────── security                              # Security - contains ca certs, pem & jks files required to connect to kafka topic
    ├──────────application-benefits.properties        # Benefits properties 
    ├──────────application-eligibility.properties
    ├──────────application-security.properties
    ├──────────application-preferences.properties
    ├──── test
    ├── pom.xml                                       # Maven pom file
    ├── README.md                                     # Instructions about executing the applicaiton
    ├── target                                        # Compiled auto generated folder
    ├──── migration-scheduler-0.0.1-SNAPSHOT.jar      # Jar file for execution
    ├── executable                                    # Project Executable folder
    ├──── migration-scheduler-0.0.1-SNAPSHOT.jar      # Jar file for execution

### Build
Execute the following command from the parent directory to build the jar file:
```
mvn clean install
```
This step creates a target folder in the parent directory which will have the jar executable file.

### Run
From the parent directory, navigate to **executable** or **target** folder and then execute the following coommand to start the application:
```
java -jar migration-scheduler-0.0.1-SNAPSHOT.jar
```

### Profiles

Following profiles are available:

- eligibility
- security
- preferences
- benefits

To run with **eligibility** profile

```
java -jar -Dspring.profiles.active=eligibility migration-scheduler-0.0.1-SNAPSHOT.jar
```

To run with **preferences** profile

```
java -jar -Dspring.profiles.active=preferences migration-scheduler-0.0.1-SNAPSHOT.jar
```

To run with **security** profile

```
java -jar -Dspring.profiles.active=security migration-scheduler-0.0.1-SNAPSHOT.jar
```

To run with **benefits** profile

```
java -jar -Dspring.profiles.active=benefits migration-scheduler-0.0.1-SNAPSHOT.jar
```

You should notice the application starting up.

### Invocation

To invoke the REST API to trigger the scheduler, please use the below urls for each profile:

**Eligibility**

```
http://{host}:8080/javainuse-kafka/eligibility/producer
```

**Preferences**

```
http://{host}:8080/javainuse-kafka/preferences/producer
```

**Security**

```
http://{host}:8080/javainuse-kafka/security/producer
```

**Benefits**

```
http://{host}:8080/javainuse-kafka/benefits/producer
```

##Creating a Topic

- Create a fork of repository - https://github.optum.com/avootuku/dc-kaas-alpha
![img_1.png](img_1.png)
- Create a folder in the forked repository, for Example "benefits"
- Add sub-folders certs, consumer_groups, topic_acls, topic_templates, topics/ctc folder inside the new folder.
- And now create all the required files in respective folders. Example Commit - https://github.optum.com/avootuku/dc-kaas-alpha/commit/627450dd8d26118d2ad989d424abe357c00dea4f
- Commit all the changes in the branch
- Raise a pull request to merge to main branch
![img.png](img.png)
- Notify Kafka team in Kafka Teams Channel 
![img_2.png](img_2.png)
- Once the pull request is approved, the new topics available on Kafka Clusters. For ex: https://grafana.optum.com/d/zXvv4B3Gzpep/kafka-topic-details?orgId=1&refresh=1m&from=now-5m&to=now&var-Datasource=KaaSDevCTCCore%20Prom&var-cluster=dev-kafka-eligibility-kaas&var-topic=mris.benefits.uhcpp&var-ConsumerGroup=4f5de2ec-7a49-4590-bd36-8b0ed5885166
![img_3.png](img_3.png)
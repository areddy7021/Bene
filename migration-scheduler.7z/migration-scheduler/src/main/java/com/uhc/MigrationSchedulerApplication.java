package com.uhc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.FileCopyUtils;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

@SpringBootApplication
@ComponentScan(basePackages = "com.uhc")
public class MigrationSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(
				MigrationSchedulerApplication.class);
	}
}
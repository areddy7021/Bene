package com.uhc.model;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Immutable
@Table(name = "STG_BENEFIT_DATA", schema = "eim")
public class Benefits {

	@Id @Column(name = "benefit_data_id")
	private Long individualId;

	@Column(name = "plan_cd")
	private String planCd;

	@Column(name = "state_cd")
	private String stateCd;

	@Column(name = "eff_dt")
	private String effectiveDate;

	@Column(name = "cancel_dt")
	private String cancelDate;

	@Column(name = "plan_platform")
	private String planPlatform;

	@Column(name = "plan_type")
	private String planType;

	@Column(name = "benefit_category_name")
	private String benefitCategoryName;

	@Column(name = "benefit_type_name")
	private String benefitTypeName;

	@Column(name = "benefit_sub_type_name")
	private String benefitSubTypeName;

	@Column(name = "benefit_text")
	private String benefitText;

	@Column(name = "sequence_order")
	private String sequenceOrder;

	@Column(name = "lst_mod_date")
	private String lstModDate;

}

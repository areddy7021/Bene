package com.uhc.repo;

import com.uhc.model.Benefits;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BenefitsRepository extends JpaRepository<Benefits, String> {
    @Query(value = "SELECT benefit_data_id, plan_cd, state_cd, eff_dt, cancel_dt, plan_platform, plan_type, benefit_category_name, benefit_type_name, benefit_sub_type_name, benefit_text, sequence_order, lst_mod_date\r\n"
    		+ "FROM EIM.STG_BENEFIT_DATA S JOIN EIM.ETL_BATCH_LOG L ON S.BATCH_ID=L.BATCH_ID\r\n"
    		+ "WHERE BATCH_STATUS='KAFKA_READY'  and ROWNUM <=100 \r\n"
    		+ "order by plan_cd, state_cd, sequence_order" , nativeQuery = true)
    List<Benefits> getBenefitsList();
}
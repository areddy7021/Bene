package com.uhc.repo;

import com.uhc.model.Eligibility;
import com.uhc.model.Security;
import com.uhc.model.Security;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EligibilityRepository extends JpaRepository<Eligibility, Long> {
    @Query(value = "SELECT  T.INDIVIDUAL_ID, T.HOUSEHOLD_ID, T.MBR_NBR, T.ASSOC_ID, T.EMP_ID, T.INSURED_CD, T.CUST_ACCT_ID, T.ENROLL_MBR_FACE_ID, T.MCARE_CLAIM_NBR, T.PROD_CD, T.SRC_SYS_CD, T.LAST_NM, T.FIRST_NM, T.MID_NM, T.GENDER_CD, T.EMAIL_ADDR, T.DAY_PHONE, \n" +
            "\n" +
            "T.EVENING_PHONE, T.DOB, T.INS_PLAN_EFF_DT, T.INS_PLAN_TERM_DT, T.SPB_STATE, T.BUSINESS, T.BOOK_OF_BUSINESS, T.REC_STATUS, T.MSG_STATUS, T.SRC_CREAT_BY, T.SRC_CREAT_DT, T.SRC_LST_MOD_BY, T.SRC_LST_MOD_DT, T.CREAT_BY, T.CREAT_DT, T.LST_MOD_BY, T.LST_MOD_DT,\n" +
            "\n" +
            "ADDR.ADDR_TYPE, ADDR.ADDR_LINE_1, ADDR.ADDR_LINE_2, ADDR.CITY, ADDR.STATE, ADDR.COUNTRY, ADDR.ZIP,HH_ADDR_START_DT, HH_ADDR_STOP_DT,\n" +
            "\n" +
            "S.SRC_SYS AS SEC_SRC_SYS, S.PERMISSION AS SEC_PERMISSION, S.CREAT_BY as SEC_CREAT_BY, S.CREAT_DT as SEC_CREAT_DT, S.LST_MOD_BY AS SEC_LST_MOD_BY, S.LST_MOD_DT AS SEC_LST_MOD_DT\n" +
            "\n" +
            "FROM EIM.STG_ELIGIBILITY_TOPIC T \n" +
            "JOIN EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID \n" +
            "JOIN EIM.STG_ELIGIBILITY_ADDR ADDR ON T.INDIVIDUAL_ID = ADDR.INDIVIDUAL_ID\n" +
            "JOIN EIM.STG_ELIGIBILITY_SECURITY S ON S.INDIVIDUAL_ID=T.INDIVIDUAL_ID \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' \n" +
            "\n" +
            "UNION \n" +
            "\n" +
            "SELECT T.INDIVIDUAL_ID, T.HOUSEHOLD_ID, T.MBR_NBR, T.ASSOC_ID, T.EMP_ID, T.INSURED_CD, T.CUST_ACCT_ID, T.ENROLL_MBR_FACE_ID, T.MCARE_CLAIM_NBR, T.PROD_CD, T.SRC_SYS_CD, T.LAST_NM, T.FIRST_NM, T.MID_NM, T.GENDER_CD, T.EMAIL_ADDR, T.DAY_PHONE, \n" +
            "\n" +
            "T.EVENING_PHONE, T.DOB, T.INS_PLAN_EFF_DT, T.INS_PLAN_TERM_DT, T.SPB_STATE, T.BUSINESS, T.BOOK_OF_BUSINESS, T.REC_STATUS, 'U' as MSG_STATUS, T.SRC_CREAT_BY, T.SRC_CREAT_DT, T.SRC_LST_MOD_BY, T.SRC_LST_MOD_DT, T.CREAT_BY, T.CREAT_DT, T.LST_MOD_BY, T.LST_MOD_DT,\n" +
            "\n" +
            "ADDR.ADDR_TYPE, ADDR.ADDR_LINE_1, ADDR.ADDR_LINE_2, ADDR.CITY, ADDR.STATE, ADDR.COUNTRY, ADDR.ZIP,HH_ADDR_START_DT, HH_ADDR_STOP_DT,\n" +
            "\n" +
            "S.SRC_SYS AS SEC_SRC_SYS, S.PERMISSION AS SEC_PERMISSION, S.CREAT_BY as SEC_CREAT_BY, S.CREAT_DT as SEC_CREAT_DT, S.LST_MOD_BY AS SEC_LST_MOD_BY, S.LST_MOD_DT AS SEC_LST_MOD_DT\n" +
            "\n" +
            "FROM EIM.STG_ELIGIBILITY_TOPIC T JOIN EIM.STG_ELIGIBILITY_ADDR ADDR ON T.INDIVIDUAL_ID = ADDR.INDIVIDUAL_ID\n" +
            "JOIN EIM.STG_ELIGIBILITY_SECURITY S ON S.INDIVIDUAL_ID=T.INDIVIDUAL_ID  WHERE T.INDIVIDUAL_ID IN \n" +
            "\n" +
            "(Select INDIVIDUAL_ID FROM EIM.STG_ELIGIBILITY_ADDR T JOIN \n" +
            "\n" +
            "EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID  \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' AND INDIVIDUAL_ID NOT IN \n" +
            "\n" +
            "(Select INDIVIDUAL_ID FROM EIM.STG_ELIGIBILITY_TOPIC T JOIN \n" +
            "\n" +
            "EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' \n" +
            "\n" +
            "))   \n" +
            "ORDER BY INDIVIDUAL_ID " , nativeQuery = true)
    List<Eligibility> getAllEligibilityList();
}
package com.uhc.repo;

import com.uhc.model.Eligibility;
import com.uhc.model.Security;
import com.uhc.model.Security;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EligibilityRepository extends JpaRepository<Eligibility, String> {
    @Query(value = "SELECT INDIVIDUAL_ID, HOUSEHOLD_ID, MBR_NBR, ASSOC_ID, EMP_ID, INSURED_CD, CUST_ACCT_ID, ENROLL_MBR_FACE_ID, MCARE_CLAIM_NBR, PROD_CD, SRC_SYS_CD, LAST_NM, FIRST_NM, MID_NM, GENDER_CD, EMAIL_ADDR, DAY_PHONE, \n" +
            "\n" +
            "EVENING_PHONE, DOB, INS_PLAN_EFF_DT, INS_PLAN_TERM_DT, SPB_STATE, BUSINESS, BOOK_OF_BUSINESS, REC_STATUS, MSG_STATUS, SRC_CREAT_BY, SRC_CREAT_DT, SRC_LST_MOD_BY, SRC_LST_MOD_DT, CREAT_BY, CREAT_DT, LST_MOD_BY, LST_MOD_DT \n" +
            "\n" +
            "FROM EIM.STG_ELIGIBILITY_TOPIC T JOIN \n" +
            "\n" +
            "EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' \n" +
            "\n" +
            "UNION \n" +
            "\n" +
            "SELECT INDIVIDUAL_ID, HOUSEHOLD_ID, MBR_NBR, ASSOC_ID, EMP_ID, INSURED_CD, CUST_ACCT_ID, ENROLL_MBR_FACE_ID, MCARE_CLAIM_NBR, PROD_CD, SRC_SYS_CD, LAST_NM, FIRST_NM, MID_NM, GENDER_CD, EMAIL_ADDR, DAY_PHONE, \n" +
            "\n" +
            "EVENING_PHONE, DOB, INS_PLAN_EFF_DT, INS_PLAN_TERM_DT, SPB_STATE, BUSINESS, BOOK_OF_BUSINESS, REC_STATUS, 'U' as MSG_STATUS, SRC_CREAT_BY, SRC_CREAT_DT, SRC_LST_MOD_BY, SRC_LST_MOD_DT, CREAT_BY, CREAT_DT, LST_MOD_BY, LST_MOD_DT \n" +
            "\n" +
            "FROM EIM.STG_ELIGIBILITY_TOPIC T WHERE INDIVIDUAL_ID IN \n" +
            "\n" +
            "(Select INDIVIDUAL_ID FROM EIM.STG_ELIGIBILITY_ADDR T JOIN \n" +
            "\n" +
            "EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' AND INDIVIDUAL_ID NOT IN \n" +
            "\n" +
            "(Select INDIVIDUAL_ID FROM EIM.STG_ELIGIBILITY_TOPIC T JOIN \n" +
            "\n" +
            "EIM.ETL_BATCH_LOG B ON T.BATCH_ID=B.BATCH_ID \n" +
            "\n" +
            "WHERE B.BATCH_STATUS='KAFKA_READY' \n" +
            "\n" +
            ")) \n" +
            "\n" +
            "ORDER BY INDIVIDUAL_ID " , nativeQuery = true)
    List<Eligibility> getAllEligibilityList();
}